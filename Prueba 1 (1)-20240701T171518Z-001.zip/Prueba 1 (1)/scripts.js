// URL de la API para obtener el tipo de cambio
const apiUrl = 'https://api.exchangerate-api.com/v4/latest/USD';

// Función para obtener el tipo de cambio de USD a CLP
async function getExchangeRate() {
    try {
        const response = await fetch(apiUrl);
        if (!response.ok) {
            throw new Error('Network response was not ok ' + response.statusText);
        }
        const data = await response.json();
        console.log('Tipo de cambio obtenido:', data.rates.CLP);
        return data.rates.CLP; // Obtener el tipo de cambio de USD a CLP
    } catch (error) {
        console.error('Fetch error: ', error);
        return null;
    }
}

// Función para convertir el valor de CLP a USD y actualizar el precio
async function convertToUSD(button) {
    const clpToUsdRate = await getExchangeRate();
    if (clpToUsdRate) {
        const priceElement = button.parentElement.querySelector('.price');
        if (priceElement) {
            const clpValue = parseFloat(priceElement.getAttribute('data-clp'));
            const usdValue = (clpValue / clpToUsdRate).toFixed(2);
            priceElement.textContent = `$${usdValue} USD`;
        } else {
            console.error('No se encontró el elemento de precio.');
        }
    } else {
        console.error('Error al obtener el tipo de cambio. Verifica la consola para más detalles.');
    }
}

// Función ficticia para agregar al carrito (puedes implementarla según tus necesidades)
function agregarAlCarrito(productoId) {
    console.log(`Producto ${productoId} agregado al carrito.`);
}